#!/bin/sh
# Run from the root of your repository: sh DELETE-FILES.sh
git rm -f "images/circle-y-1753-5.jpg"
git rm -f "images/circle-y-1753-6.jpg"
git rm -f "images/circle-y-alabama-flex2-gaiter-1581-5.jpg"
git rm -f "images/circle-y-walnut-grove-1157-2.jpg"
git rm -f "images/circle-y-walnut-grove-1157.jpg"
git rm -f "images/payments/opay.jpg"
git rm -f "products/circle-y-walnut-grove-flex2-1157.html"
