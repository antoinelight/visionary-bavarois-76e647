HOW TO APPLY THESE CHANGES TO YOUR GITHUB REPOSITORY

1. Unzip this folder.
2. Copy everything in it (except README.txt, FILES-TO-DELETE.txt and DELETE-FILES.sh)
   into the ROOT of your local repository, and choose "Replace" when asked.
3. Delete the 7 old files listed in FILES-TO-DELETE.txt
   (from the repository root run:  sh DELETE-FILES.sh).
4. Commit and push:
     git add -A
     git commit -m "Domain, Gmail, payments, SEO, menu fix"
     git push
5. Netlify redeploys automatically after the push.
